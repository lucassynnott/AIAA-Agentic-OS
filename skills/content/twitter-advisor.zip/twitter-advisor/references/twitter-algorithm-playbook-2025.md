# THE TWITTER ALGORITHM PLAYBOOK 2025

Last Updated: October 2025
Based on: Twitter's open-sourced 48M-parameter neural network ranking system

## THE TRUTH ABOUT HOW TWITTER WORKS

Twitter processes 500 million tweets daily. Every tweet competes against half a billion other posts.

### The Two-Stage Ranking System

**STAGE 1: Candidate Sourcing**
- Twitter pulls ~1,500 potential tweets for each user's feed
- 50% from keyword/topic matching (what you tweet about)
- 50% from your follower network behavior (who engages with you)

**STAGE 2: The Heavy Ranker**
- A 48-million-parameter neural network scores every tweet
- Predicts likelihood of engagement (RT, reply, like, etc.)
- Processes in under 1.5 seconds
- Runs 5 billion times per day

**Formula:** `Tweet's final ranking = Engagement prediction × Your credibility score × Content quality`

If any of these three factors suck, reach dies.

## THE ENGAGEMENT WEIGHT SYSTEM

The algorithm doesn't treat all engagement equally.

### 🔥 VERY HIGH IMPACT (These Win or Lose the Game)

| Signal | Weight | Why It Matters |
|--------|--------|----------------|
| **Retweets** | 1st RT = 100% value<br>2nd RT = +58%<br>4th RT = +32%<br>8th RT = +17% | Logarithmic scaling. First 10 RTs worth more than next 100. Get early RTs or die. |
| **Replies** | Massive multiplier | Especially in first 30 minutes. Each reply extends your tweet's lifespan. |
| **Author Replies** | Highest weight | YOU replying to your own tweet = algorithm thinks it's important conversation. Reply to every comment. |

### ⚡ HIGH IMPACT (These Build Momentum)

| Signal | Weight | Why It Matters |
|--------|--------|----------------|
| **Likes** | High (logarithmic) | Formula: weight × log₂(1 + likes). First 8 likes = exponential boost. |
| **Video 50%+ watch** | High | Minimum 10-second threshold. Keep videos under 60 seconds. |
| **Dwell time (15+ sec)** | High | Now equals video watch-time weight. Long-form text that keeps readers matters. |

### 💎 MEDIUM-HIGH IMPACT (Hidden Metrics)

| Signal | Weight | Why It Matters |
|--------|--------|----------------|
| **Bookmarks** | Medium-High | People saving for later = quality signal. |
| **Profile clicks** | Medium | Hidden metric. Make people curious about WHO you are. |
| **"See more" clicks** | Medium | Truncated tweets that get expanded = engagement signal. |

### ☠️ CATASTROPHIC PENALTIES (Avoid At All Costs)

| Signal | Penalty Range | Impact |
|--------|---------------|--------|
| **Reports** | -20,000 to 0 | Instant visibility death. One report can kill a tweet. |
| **"Not Interested"** | -1,000 to 0 | Severe suppression across network. |
| **Mutes/Blocks** | Heavy penalty | Algorithm learns you're not relevant to that person's network. |
| **Unfollows after view** | Negative feedback | You're being marked as low-value. |

## YOUR CREDIBILITY SCORE (TwEEPCred)

Every account has a "credibility score" that multiplies (or kills) your reach.

**Key Insight:** A tweet from a high-credibility account with 10 likes beats a tweet from a low-credibility account with 100 likes.

### ✅ POSITIVE REPUTATION FACTORS

| Factor | Boost | How to Optimize |
|--------|-------|-----------------|
| **Verified badge** | Fixed score of 100 | Get verified. Non-negotiable if you're serious. |
| **Account age** | Formula: min(1.0, log(1 + age_days/15)) | Older accounts = more credibility. Can't fake this. |
| **Mobile app usage** | +50% boost | POST FROM THE MOBILE APP. Not web. Not schedulers. |
| **Follower engagement rate** | Multiplier effect | % of followers who actually engage with you. Quality > quantity. |
| **Following/Follower ratio** | Must be <0.6 | **CRITICAL THRESHOLD.** Over 0.6 = severe penalty. |

### ❌ REPUTATION KILLERS

**The Following/Follower Ratio Rule:**
- Ratio >0.6 = Severe algorithmic penalty
- Ratio >1.0 = You're following more than follow you = algorithm thinks you're spam
- Your ratio MUST be under 0.6 or you're being suppressed on every tweet

**Examples:**
- 1,000 followers? You can follow max 600 accounts.
- 10,000 followers? You can follow max 6,000 accounts.
- Following 2,000 but only have 1,500 followers? You're fucked.

**Other Killers:**
- Low follower engagement (followers who never like/RT/reply)
- Frequent reports or blocks from users
- Spammy posting patterns (too many links, hashtags, @ mentions)
- Posting only from web/schedulers (no mobile usage)

## THE 30-MINUTE WINDOW

The algorithm's core decision happens in the first 30 minutes after you post.

**Critical Truth:** A tweet with 8 likes in 5 minutes beats a tweet with 80 likes in 5 hours.

### The Logarithmic Engagement Formula

`Final Score = Σ(signal_weight × log₂(1 + engagement_count))`

**What this means:**
- First 10 engagements = exponentially more valuable than next 100
- Early velocity (first 30 min) determines algorithmic momentum
- If your tweet doesn't get traction in 30 minutes, it's dead

### The 30-Minute Checklist

**MINUTE 0-5: Critical Launch Window**
- Goal: 3-5 engagements (likes, RTs, replies)
- Tactic: Seed to 3-5 engaged friends immediately
- Why: First 8 likes provide 100%+ of single-engagement value

**MINUTE 5-15: Momentum Building**
- Goal: First retweet + 2-3 replies
- Tactic: Reply to any comments yourself (author reply = VERY HIGH weight)
- Why: Retweets and replies are weighted far higher than likes

**MINUTE 15-30: Algorithmic Decision Point**
- Goal: 10+ total engagements with at least 2 RTs
- Tactic: If momentum is building, quote tweet it from another account or thread a follow-up
- Why: Algorithm decides if your tweet gets pushed to "For You" feeds at scale

**After 30 Minutes:**
- <10 engagements = tweet is dead
- 10-20 engagements with RTs/replies = entering scale mode
- >20 engagements = you've won—algorithm will push it to wider network

## CONTENT FORMAT HIERARCHY

### 🚀 ALGORITHMIC BOOST FORMATS

Ranked from highest to lowest boost:
1. **Trending topics** – Massive reach multiplier
2. **Native video** – Tracked at 10-sec minimum, scored at 50% completion
3. **Images** – Medium boost, especially with alt-text
4. **News URLs** – Domain authority matters (NYT link > random blog)
5. **Text-only** – Relies purely on engagement velocity (no format boost)

### ⚠️ FORMAT PENALTIES

| Format Issue | Penalty | How to Avoid |
|--------------|---------|--------------|
| **3+ hashtags** | Medium damping | Use 0-2 hashtags max. Preferably 0. |
| **Multiple @mentions** | Looks like spam | Max 1-2 mentions unless natural conversation. |
| **All-caps text** | Low-quality penalty | Use proper capitalization. |
| **Thread-gating** | Shadow throttle | Never say "Reply for part 2" or "Like to unlock thread." |
| **Engagement bait** | 2025 algo punishes hard | No "Like if you agree" or "RT to support." |

### 📊 2025 CONTENT PERFORMANCE DATA

**Singles vs. Threads:**
- Short, dense tweets (≤280 chars) = 3× impressions-per-word vs threads
- Threads are dead unless you're already massive
- Algorithm rewards concise, high-density content

**Watch-time = Read-time:**
- Video and text now weighted equally for dwell
- A 60-second video = A 60-second read
- Optimize for dwell time: Use line breaks, create "see more" cliffhangers

## INSTANT DEATH PENALTIES

### 🚨 ACCOUNT-LEVEL DEATH PENALTIES

| Penalty | Impact | How to Fix |
|---------|--------|------------|
| **Following/Follower ratio >0.6** | Severe reach suppression on all tweets | Unfollow accounts until ratio <0.6. Do this immediately. |
| **High report rate** | -20,000 weight per report | Don't post controversial/spam content that gets reported. |
| **Low follower engagement** | Credibility multiplier tanks | Remove dead followers. Quality > quantity. |
| **Web-only posting** | Missing +50% mobile boost | Post from mobile app, not web or schedulers. |

### 💀 TWEET-LEVEL DEATH PENALTIES

| What You Did | Why It's Death | Example to Avoid |
|--------------|----------------|------------------|
| **Thread-gating** | Shadow throttle risk | "Reply 'AI' to unlock part 2" ❌ |
| **Obvious engagement bait** | 2025 algo specifically targets | "Like if you agree!" ❌ |
| **All caps** | Low-quality flag | "THIS IS HUGE NEWS" ❌ |
| **3+ hashtags** | Spam signal | "#Marketing #Business #Growth #AI #Automation" ❌ |
| **Link spam** | External link without context | Just posting a link with no text ❌ |
| **Mass @mentions** | Spam pattern | @person1 @person2 @person3 @person4 ❌ |

### The "Not Interested" Death Spiral

If 5-10% of people who see your tweet click "Not Interested," you're done.

**How it happens:**
1. You post something off-brand or low-quality
2. Your followers click "Not Interested"
3. Algorithm learns your content isn't relevant
4. Your next 10 tweets get suppressed automatically
5. You wonder why your reach died

**How to avoid:**
- Stay on-brand. Every. Single. Tweet.
- Don't chase trends outside your niche
- Don't post random life updates if you're a business account
- Consistency = Algorithm learns what you're about

## GAMING TACTICS THAT ACTUALLY WORK

### 🎯 TACTIC 1: The Engagement Seed

**What:** Prime your tweet with early engagement to trigger algorithmic momentum.

**How:**
1. Write your tweet
2. Before posting, DM 3-5 engaged friends: "About to drop a banger, would love a RT"
3. Post the tweet
4. Friends engage within first 5 minutes
5. Algorithm sees early velocity → pushes to wider network

**Why it works:** First 8 engagements are worth 100%+ of value. You're gaming the logarithmic curve.

**Warning:** Don't use engagement pods or fake accounts. Real friends/colleagues only. Algorithm detects fake engagement patterns.

### 🎯 TACTIC 2: Author Reply Amplification

**What:** Reply to your own tweet to boost its visibility and extend its lifespan.

**How:**
1. Post your main tweet
2. Wait 5-10 minutes
3. Reply to your own tweet with additional context, a follow-up thought, or a question
4. Reply to every comment on your tweet

**Why it works:** Author replies have VERY HIGH weight. Algorithm interprets this as "important conversation happening here."

**Example:**
- Main tweet: "Most agencies waste 60 hours building custom automations for every client"
- Your reply 10 min later: "The math: 60 hours × $100/hr = $6,000 in labor. But you only charged $5,000. You just lost money on delivery."

### 🎯 TACTIC 3: The Momentum Thread

**What:** If a tweet starts getting traction, thread a follow-up to capture the momentum.

**How:**
1. Post your tweet
2. Monitor first 30 minutes
3. If you hit 15+ engagements with 2+ RTs, immediately thread a follow-up
4. The follow-up gets boosted by the momentum of the original

**Why it works:** Algorithm boosts your next tweet if previous one performed well (momentum effect).

### 🎯 TACTIC 4: Network Effect Multiplier

**What:** Build a small, highly engaged audience instead of a large, dead follower base.

**How:**
1. Audit your followers monthly
2. Remove dead accounts (0 engagement in 90 days)
3. Engage heavily with your top 50 most active followers
4. Retweet them, reply to them, DM them
5. They become your algorithmic amplifiers

**Why it works:** Algorithm tracks "how many of User A's followers engage with User B." Retweets from engaged followers are worth 3-5× random RTs.

**The math:**
- 1,000 followers with 10% engagement rate = 100 people regularly boost your content
- 10,000 followers with 1% engagement rate = 100 people regularly boost your content
- Same reach, but first account has way better credibility score

### 🎯 TACTIC 5: Timing + Network Graph Optimization

**What:** Post when your core followers are most active to maximize first-30-minute velocity.

**How:**
1. Check Twitter Analytics for when your audience is online
2. Post during those peak hours
3. Your engaged followers see it immediately → early engagement → algorithmic boost

**Why it works:** Network graph signal is weighted heavily. If your followers engage immediately, algorithm thinks your content is high-quality.

**Pro tip:** If your audience is global, test posting at different times and track first-30-minute engagement rate. Find your optimal window.

### 🎯 TACTIC 6: The Hook Cliffhanger

**What:** Write tweets that get truncated with "see more" to drive expansion clicks.

**How:**
1. Write your tweet to exactly 280 characters (or slightly over)
2. Make sure the first 140 characters are a hook that demands completion
3. Put the payoff after the "see more" break
4. Users click "see more" = dwell time signal + engagement signal

**Why it works:** "See more" expansion rate is a tracked medium-weight signal. You're gaming dwell time.

**Example structure:**
```
Most automation agencies fail because [HOOK THAT CREATES TENSION]
[see more break]
Here's what they do instead: [PAYOFF]
```

### 🎯 TACTIC 7: The Bookmark Trap

**What:** Create content so valuable people bookmark it for later.

**How:**
1. Post tactical, save-worthy content (frameworks, checklists, specific numbers)
2. Don't give everything away—create "I need to come back to this" feeling
3. End with implicit "you'll need this later" framing

**Why it works:** Bookmarks are a medium-high weight signal. Algorithm thinks "this is reference-quality content."

**Bookmark-worthy content types:**
- Frameworks with specific steps
- Math breakdowns with real numbers
- Contrarian takes with proof
- Tactical playbooks
- "I'll need this when I do X" content

### 🎯 TACTIC 8: Controversy Bait (Advanced)

**What:** Post contrarian takes that drive replies (HIGH weight signal).

**How:**
1. Identify a common belief in your niche
2. Post the opposite opinion with conviction
3. Back it with proof or logic
4. Let the replies roll in (even disagreements count as engagement)

**Why it works:** Replies, especially in first 30 minutes, are VERY HIGH weight. Controversy drives replies.

**Warning:** Don't be controversial just for engagement. Stay on-brand. Don't cross into getting reported.

### 🎯 TACTIC 9: The Profile Click Hook

**What:** Make people curious enough to click your profile (medium weight signal).

**How:**
1. Reference your business/results without explaining fully
2. Tease your methodology without giving it all away
3. Make them think "who is this person?"
4. Ensure your bio/pinned tweet converts that curiosity

**Why it works:** Profile clicks are a hidden metric driving organic reach. Algorithm thinks "people are interested in this account."

### 🎯 TACTIC 10: The Engagement Velocity Hack

**What:** Post, then immediately do something to drive first 5 minutes of engagement.

**How:**
1. Post your tweet
2. Immediately DM it to 1-2 people who would find it valuable: "Thought you'd find this interesting"
3. Or: QT your own tweet from another account with additional context
4. Or: Post in a relevant Slack/Discord with "just posted this"

**Why it works:** First 5 minutes are the most critical window. You're artificially creating early velocity to trigger algorithmic momentum.

**Warning:** Don't spam. Don't be inauthentic. Only share with people who'd genuinely care.

## THE DAILY/WEEKLY/MONTHLY CHECKLIST

### 📅 DAILY CHECKLIST

**Every time you post:**
- [ ] Posted from mobile app? (+50% boost)
- [ ] Hook in first 40 characters?
- [ ] One clear insight/payoff?
- [ ] 0-2 hashtags max?
- [ ] 0-2 emojis max?
- [ ] No engagement bait language?
- [ ] Seeded to 3-5 engaged friends for early velocity?
- [ ] Replied to every comment in first 30 minutes?

**End of day:**
- [ ] Replied to all mentions/comments? (Author engagement = VERY HIGH weight)
- [ ] Engaged with your top 10 most active followers? (Network effect multiplier)

### 📊 WEEKLY CHECKLIST

**Every Sunday:**
- [ ] Review top 3 tweets from the week—what drove early replies/RTs?
- [ ] Analyze worst-performing tweet—what killed it? (High "not interested" rate? Poor hook?)
- [ ] Check following/follower ratio—still under 0.6?
- [ ] Audit last 20 followers—any dead accounts to remove?
- [ ] Identify 1-2 hook types that performed best—use more next week

**Engagement audit:**
- [ ] What % of your followers engaged this week?
- [ ] If <5%, your follower quality is hurting your credibility score
- [ ] Consider removing dead followers

### 🗓 MONTHLY CHECKLIST

**First of every month:**

**Account health audit:**
- [ ] Following/follower ratio check (MUST be <0.6)
- [ ] Remove dead followers (0 engagement in 90 days)
- [ ] Check follower engagement rate (goal: >5% of followers engaging monthly)
- [ ] Verify mobile posting % (should be 100%)

**Content audit:**
- [ ] Top 10 tweets of the month—what patterns drove engagement?
- [ ] Test all 12 hook types—which 3 performed best?
- [ ] Analyze first-30-minute velocity on top tweets
- [ ] Identify which content buckets got most RTs

**Competitive analysis:**
- [ ] Find 3 accounts in your niche with high engagement
- [ ] Study their hooks, structure, timing
- [ ] Identify what they're doing that you're not

**Algorithm updates:**
- [ ] Check Twitter's engineering blog for algorithm changes
- [ ] Adjust tactics based on any new ranking signals

## THE ALGORITHM IN ONE PARAGRAPH

Twitter's 2025 algorithm scores tweets using a 48M-parameter neural network that weighs retweets and replies exponentially higher than likes, with logarithmic scaling that makes the first 10 engagements worth more than the next 100. Your author credibility score (TwEEPCred) multiplies every tweet's reach based on verification, account age, follower ratio (<0.6 critical), and mobile usage (+50% boost). Content is sourced 50% from search-index (topic match) and 50% from network graph (follower behavior), then ranked by early engagement velocity (first 30 min) and dwell time (15+ sec for text, 50% completion for video). Negative signals like reports (-20,000 weight) or "not interested" (-1,000) kill reach instantly. Singles outperform threads 3× on impressions-per-word because the algorithm rewards concise, high-density content that drives profile clicks, "see more" expansion, and saves—not obvious engagement bait, which is actively penalized in 2025.
