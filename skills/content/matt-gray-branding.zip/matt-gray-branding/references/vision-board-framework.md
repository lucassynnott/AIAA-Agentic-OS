# The Founder OS Vision Board - Creating a Clear Vision

## Why Vision Matters

Having a clear vision is absolutely essential for building a successful online business. If we're going to inspire customers, a community, our team, potential investors - we need to have a clear vision.

Over my 12 years, I've really refined this model which I call the Founder OS Vision Board.

## The Founder OS Vision Board Structure

The vision board includes:

1. **Company Values** - Values that guide hiring, culture, and content strategy
2. **Niche** - Your vision, mission, and specific niche
3. **Marketing System** - Target market, unique value proposition, process, guarantee
4. **10 Year Goals** - Your decade vision
5. **3 Year Goals** - Milestones to reach in 3 years
6. **1 Year Plan** - Annual objectives
7. **90 Day Plan** - Quarterly goals (SMART goals)
8. **Opportunities** - What you need across People, Product, and Process

## My Founder OS Vision Board Example

### Company Values
1. **Every day is day one** - Show up every day ready to attack it
2. **Make magic possible** - Fully express ourselves, give our best creatively
3. **Automate, Eliminate, Delegate** - Work on the right tasks only
4. **Invent and Wander** - Creativity fueled by travel and nature
5. **Optimize for Flow** - Four hours of deep work daily (6am-10am)

### Niche
- **Vision**: Build a community of 10 million entrepreneurs changing the world
- **Mission**: Inspire 10 million entrepreneurs to live their dreams
- **Niche**: Founder Operating Systems

### Marketing System

**Target Market:**
Solopreneurs and serial entrepreneurs looking for their North Star
- People taking business from nothing to something, need proven systems
- Entrepreneurs with multiple successful businesses who want to run business without it running them into ground

**Unique Value Proposition:**
- Founder OS Framework
- Founder OS Assessment
- Founder OS Community

**Process:**
1. Founder OS Program (course)
2. Community
3. Mastermind
4. SaaS tool (Henzo)

**Guarantee:** Money-back guarantee

### 10 Year Goals
- Serve 1 million people with Founder OS program
- Build community of 10 million people
- Henzo: 1 million monthly users

### 3 Year Goals
- Audience of 10 million (across LinkedIn, Twitter, YouTube, TikTok)
- Email newsletter: 1 million subscribers
- Henzo: 200,000 monthly users
- Founder OS community: 10,000 people
- Founder OS program: Serve 200,000+ people
- Buy retreat centers in Hawaii, Costa Rica, and Japan for founder workshops
- Mastermind: 1,000+ people (200+ groups)

### 1 Year Goals
- Audience: 500k across Twitter and LinkedIn
- Email list: 50k
- Henzo: Created with 1,000 raving fans
- Founder OS community membership: 1,000
- Founder OS program: Served 1,000 people

### 90 Day Goals (Example - these update quarterly)
- Audience: 200k across Twitter and LinkedIn
- Email list: 30k
- Henzo tool MVP: Done and launched
- Founder OS community membership: 90
- Founder OS program: Served 120 people

### Opportunities (People, Product, Process)

**People:**
- Hire growth assistant (marketing weapon for audience growth)
- Hire no-code engineer (build and iterate product quickly)

**Product:**
- Launch Henzo software tool
- Plan and launch Founder OS community

**Process:**
- Process out marketing needs (document everything)
- Finalize course process
- Finalize community process
- Finalize SaaS onboarding process

## How to Use the Vision Board

### 1. Start with the 10-Year Vision
Look out to the future - what does your dream future look like in 10 years? Be as broad or as descriptive as you want. There's no right or wrong way.

### 2. Work Backwards to 3 Years
Put a date to it. Really imagine this. Visualize it. Make it happen.

### 3. Create Your 1-Year Vision
Take your time here. Think about what you need from a:
- **Marketing** standpoint
- **Community** standpoint
- **Revenue** standpoint
- **Team** standpoint
- **Product** standpoint

### 4. Define 90-Day Goals
These need to be **SMART goals**: Specific, Measurable, Achievable, Relevant, Time-bound

**Example of SMART vs Non-SMART:**
- ❌ "I want my audience to be amazing in 90 days"
- ✅ "I want my audience across Twitter and LinkedIn to be at 200,000"

It's either red light/green light - yes or no. You need to know objectively if you hit it.

### 5. Break Down into People, Product, Process

**People:**
- Who do I need to hire?
- Who do I need to recruit?
- Who do I need to onboard?

**Product:**
- What do I need to launch?
- What do I need to plan?
- What features do I need to build?

**Process:**
- What systems do I need to document?
- What processes do I need to create?
- What onboarding flows do I need?

## The Personal Board Meeting

This is a monthly accountability system to accomplish your vision.

### Structure

**Monthly Personal Board Meeting includes:**

1. **Your Ikigai** (at the top - reminder of your calling)
2. **Personal 30-Day Goals** (around 5 goals)
3. **Business 30-Day Goals** (around 5 goals)
4. **End-of-Month Reflection:**
   - What went well?
   - What didn't go well?
   - What did I learn?

### Example Personal 30-Day Goals
- Do yoga one time per week
- Mobilize Twitter army to get to 250k by end of year
- Mobilize LinkedIn army
- Seek out different mentors and advisors
- Learn new concepts/read new books
- Go on dates

### Example Business 30-Day Goals
- Audience goals (specific numbers)
- Partnership goals
- Product goals
- Revenue goals
- Hiring goals

### How to Use It

**Beginning of Month:**
- Fill out your personal 30-day goals (ladder up to 90-day goals)
- Fill out your business 30-day goals (ladder up to 90-day goals)

**End of Month:**
- Reflect on what went well
- Reflect on what didn't go well
- Document what you learned
- Use insights to plan next month

**The Result:**
Every task you work on each day ladders up to:
- Your 30-day goals →
- Your 90-day goals →
- Your 1-year plan →
- Your 3-year goals →
- Your 10-year vision

This is how you accomplish your dreams day by day, relentlessly.

## Creating Your Own Vision Board

### Step 1: Fill Out Company Values
Create unique values that represent your company's personality. These will:
- Guide hiring decisions
- Define your culture
- Direct your content strategy
- Help you say NO to opportunities not aligned

### Step 2: Define Your Niche
Based on Module 1 (Ikigai), input:
- Your vision
- Your mission
- Your specific niche

### Step 3: Craft Your Marketing System
- **Target Market**: Who specifically are you serving?
- **Unique Value Proposition**: What makes you different?
- **Proven Process**: How do you deliver value?
- **Guarantee**: What do you promise?

### Step 4: Set Goals (10 Year → 3 Year → 1 Year → 90 Day)
Work backwards from your 10-year vision to create milestones.

### Step 5: Identify Opportunities
What do you need to accomplish your 90-day goals across:
- People (hiring, recruiting, onboarding)
- Product (launching, planning, building)
- Process (systems, documentation, workflows)

## Vision Board Best Practices

### Print It Out
I print my two-page vision board and put it:
- In my bedroom
- On my bathroom mirror
- Near my desk at work

Having it visible allows you to subconsciously work toward these things and take small daily actions.

### Update It Quarterly
Every 90 days:
- Review what you accomplished
- Set new 90-day goals
- Update your longer-term goals if needed
- Refine your values, vision, or processes

### Use It in Conversations
I constantly refer back to my vision when:
- Speaking to my team
- Hiring people
- Reaching out to partners
- Pitching customers
- Seeking mentors

Example: "Hey, this is Matt from Herb. Our mission is to change the way the world views cannabis. Our vision is to get anyone in the world Cannabis in under 15 minutes and free every person incarcerated for cannabis globally. I wanted to chat with you about..."

### Share It With Your Team
Your team needs to see you have a clear vision. When you bring someone on:
- Ensure they fit your company values
- Confirm they can complete things in your vision
- Show them where you're going and how they fit in

## Why This Works

### 1. Creates Alignment
Everyone on your team knows where you're going and how their work contributes.

### 2. Provides Focus
When opportunities come up, you can quickly evaluate: "Does this help us achieve our 90-day goals?" If not, say no.

### 3. Builds Accountability
You have objective metrics. You can't hide from whether you hit your goals or not.

### 4. Enables Role Modeling
When you set SMART goals and hit them, your team learns to do the same.

### 5. Reverse Engineers Success
Instead of hoping for success, you're building a specific roadmap to get there.

## Common Mistakes to Avoid

❌ **Setting vague goals** - "Be successful" vs "Hit $500k MRR"
❌ **Not updating it** - Vision boards are living documents
❌ **Making it perfect** - Done is better than perfect; iterate as you learn
❌ **Not sharing it** - Your team can't help you achieve what they don't know
❌ **Ignoring it** - Review it weekly at minimum, daily is better

## Quarterly Review Process

**December 30, March 30, June 30, September 30:**

1. **Reflect** on the past quarter:
   - What did I accomplish?
   - What gave me energy?
   - What sucked my energy?
   - What went well?
   - What didn't go well?

2. **Create** new quarterly goals for next 90 days

3. **Update** vision board based on learnings

4. **Share** updated vision with team

## Annual Review Process

**December 23 - January 3 (approximately):**

1. **Unplug** for 4 days - complete break
2. **Journal** for 3 days:
   - Reflect on past year goals
   - What went well, what didn't
   - What gave me energy, what drained me
   - What I want to cut, what I want to add
3. **Create** next year's big goals
4. **Ensure** I'm working on things that bring me energy

## The Power of Clarity

When you have a clear vision:
- Opportunities become easier to evaluate
- Hiring becomes more effective
- Team alignment improves
- You waste less time
- You move faster
- You build more leverage
- You accomplish more with less stress

**Remember:** This is a continual work in progress. Don't be too hard on yourself. Done is better than perfect. Experimenting is better than perfection. Just get started.

Let the rubber hit the road, let the pen go on paper, and begin typing your responses. I tried to make this as plug and play as humanly possible.

This system works. I've used it across multiple businesses to drive incredible results. The founders that have filled this out - over 300 plus now - the traction is insane.

This is an absolute weapon for acceleration.

Let's get it done and win together!
