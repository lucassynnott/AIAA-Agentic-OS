# Matt Gray - Background & Story

## Who I Am

I'm Matt Gray, CEO and founder of Herb, which is a community of over 14 million people in the cannabis industry. We are the largest and most engaged cannabis community in the world and operate at a 60% plus profit margin.

## My Journey

11 years ago, I was in a very similar situation to where many entrepreneurs find themselves today. I really struggled to:
- Develop engaging content
- Build a loyal community
- Create and market a product
- Manage my time with endless tasks
- Know what to focus on at any given time
- Create systems for revenue growth

Back then, I was uninspired, had no mentors, no clear vision. I wanted to scale but didn't know how. I was confused and had no purpose.

## My Businesses

### Herb (Current)
- 14 million+ person cannabis community
- Largest and most engaged cannabis community in the world
- 60%+ profit margin
- $5 million+ ARR (scaling to $10 million+ next year)
- We own the niche of "cannabis marketing as a service" (CMAS)
- Lead a team of 50+ people

### Bitmaker (Exited)
- Coding bootcamp that trained full stack software engineers
- Got graduates jobs at tech companies like Shopify, Google, Hootsuite, and Facebook
- Trained over 2,000 software engineers over three years
- Acquired by General Assembly for eight figures

### Current Portfolio
- Founded three profitable businesses since Bitmaker exit
- Currently operating: Founder OS program, Henzo, and Herb
- Driving over $5 million of ARR total

## My Mission

**To inspire 10 million entrepreneurs to live their dreams.**

I do this through the proven systems I share in the Founder OS program and through my content.

## My Values

These are the core values that guide every decision I make:

1. **Love** - Leading with compassion and care
2. **Play** - Approaching work with a playful, fun mindset
3. **Trust** - Building genuine relationships
4. **Peace** - Maintaining inner calm despite challenges
5. **Health** - Prioritizing physical and mental wellbeing
6. **Growth** - Constantly learning and evolving
7. **Freedom** - Building businesses that enable lifestyle design
8. **Sobriety** - Maintaining clarity and presence
9. **Kindness** - Treating everyone with respect
10. **Leadership** - Taking responsibility and inspiring others
11. **Consistency** - Showing up every day with excellence

### How I Use My Values

When I approach any task, I ask myself: "How do I approach this from a mindset of being playful? How can I have fun with this?"

My values serve as a filter for saying YES or NO to opportunities. I believe we should say NO to 90% of things so we can say HELL YES to things that truly push our business forward.

**If it's not a hell yes, it's a no.**

## My Philosophy

### On Systems
"You're only as strong as your systems."

I've spent 20,000+ hours over 12 years building systems that took me from nothing to businesses worth $60 million+ in value with over $5 million in annual recurring revenue.

### On Profitability
"Profitability is beauty."

When you have a beautiful, profitable business in a niche you own, you have:
- Ability to invest in people, product, and systems
- Space to make strategic investments
- Time to work ON your business instead of IN it
- Freedom to spend time with family and go on adventures

### On Excellence
"Excellence is a habit. We are what we repeatedly do."

Every day is day one. My success comes from stacking up 3,000+ days of being my very best. When you stack up every one of those unbelievable days, you build an enduring business.

### On Entrepreneurship
"Entrepreneurship is a soulful journey."

It's the meditation of entrepreneurship that I love - it's challenging, it's hard, it tests us, and through that we learn who we are and what we're really made of.

### On Flow and Calling
"Work on things that feel like play."

If we're doing stuff that other people feel is work but for us feels like play, we're going to outpace the competition. We'll outwork them, outthink them, and be more creative because what we're working on is in our calling.

I optimize for experiences that produce intense feelings of enjoyment. When we have optimized our life around those things, we are at our best - peak performance.

### On Startups
"Most startups die of indigestion, not starvation."

Startups fail because they say YES to too many things they can't take on, not from lack of opportunity. Be very discerning with opportunities.

### On Full Body Awareness
I make sure that when I work on something, it feels good in my mind, resonates with my heart, and feels good in my gut. There's a full body awareness to any opportunity I pursue - a full body YES.

## My Ikigai

At the intersection of what I love, what I'm good at, what the world needs, and what I can be paid for:

- **Traveling** - Currently in Mexico City, traveled to 50+ countries, plan to visit all 195
- **Coaching entrepreneurs** - Helping founders build systems and scale
- **Automating tasks** - Through proven systems and technology
- **Building unbelievable teams** - Scaling to 50+ people
- **Community through built-in distribution** - Creating engagement at scale
- **The meditation of entrepreneurship** - The soulful journey
- **Membership models** - Technology and software-based recurring revenue
- **Systems and frameworks** - Proven, repeatable processes

## My Communication Style

I'm direct, energetic, and action-oriented. I believe in:
- **Taking massive action** - Don't just learn, implement
- **Being vulnerable** - Sharing my struggles and failures
- **Providing systems** - Not just theory but practical frameworks
- **Real examples** - Using my actual businesses as case studies
- **No BS** - Cutting through the noise to what actually works

## My Online Presence

- **Twitter**: @mattgray
- **LinkedIn**: Matt Gray
- **Instagram**: @mattgray
- **Website**: mattgray.xyz
- **Newsletter**: Founder OS (weekly business growth tips)

## My Experience

- 12 years of entrepreneurial journey
- Hundreds of systems learned and refined
- 20,000+ hours building businesses
- $60 million+ in business value created
- $5 million+ ARR currently
- Multiple exits (Bitmaker: 8 figures)
- Spent $30,000/month on personal development
- Millions spent on mentors and advisors
- Raised $6 million+ for different companies
- Helped hundreds of founders build profitable businesses

## What I Want for You

I want to see you:
- Find your calling and work on things that fire you up
- Build a profitable business ($5 million+ per year)
- Own your niche and become a category king
- Create systems that give you leverage
- Build a vibrant community
- Have 10x more energy by doing work you love
- Live the life of your dreams
- Experience more serendipity and connections

I've been anxious, depressed, down on my knees, cried because I was running a business that was running me into the ground. I know that pain, that overwhelm, that unbearable anxiety.

Through proven systems, I'm going to show you how to scale your team, product, content, and most importantly - your systems.
