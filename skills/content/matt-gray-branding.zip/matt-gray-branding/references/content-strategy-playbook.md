# Content Strategy & Community Growth Playbook

## The Marketing Engine Funnel

Our goal is to drive people from awareness through to action:

**AIDA Framework:**
1. **Awareness** - Get discovered, drive massive awareness online
2. **Interest** - Build trust with dream customer
3. **Desire** - Create genuine desire, build deep relationships
4. **Action** - Drive them to core action (buy, sign up, engage)

## The Two-Page Content Strategy

This is the exact system I've used to:
- Grow my newsletter over 71% month over month
- Grow Twitter to 100k+ in 5 months
- Grow LinkedIn to 100k+ in 5 months
- Generate 28 million views on a single thread
- Build communities of 14 million+ people

### Page 1: Content Playbook

**1. Company Mission, Vision, Niche**
Start with your WHY. People don't buy what you do, they buy WHY you do it.

**2. Target Market**
Who specifically are you creating content for?

**My Example (Founder OS):**
- Solopreneurs
- Serial entrepreneurs
- Creators
- People unclear of their goals
- People who want to work less and make more
- People with no North Star
- People who want to build systems for success

**3. Brand Values (3-5 values)**
These are the personality of your brand. Different from personal values.

**My Example:**
- **Authoritative** - Be the best, be the authority
- **Inspiring** - Delight founders, build a movement
- **Dedicated** - Ensure success of every founder
- **Creative** - Push the envelope, constantly iterate
- **Fun** - Good vibes all around, have a good time

**Why brand values matter:**
They filter what content you should and shouldn't create. If it doesn't embody your brand values, say NO.

**4. Content Categories (4 categories)**
The drumbeat of your marketing. The topics you'll create content about consistently.

**My Example:**
- Marketing
- Business
- Mindfulness
- Health

**5. Content Formats (3 formats)**
The types of content you'll create.

**Options:** How-tos, Recipes, Stories, Lists, Myths, Guides, City Guides, Do's and Don'ts

**My Example:**
- How-to's
- Guides
- Lists

**6. Curation Sources**
Where you draw inspiration and save content you love.

**My Example:**
- Twitter bookmarks
- LinkedIn saves
- Instagram collections
- Twemex (Chrome extension to find top tweets)

**7. Content Franchises**
Regular content that comes out on a schedule. Your "shows."

**Examples:**
- Netflix has Stranger Things
- HBO has Sopranos
- Founder OS has: Saturday morning newsletter, Twitter threads (Wed & Sat)

**My Example:**
- Founder OS Newsletter - Every Saturday AM (one business growth tip)
- Twitter Threads - Every Wednesday and Saturday

**8. Best in Class Examples**
Specific examples of your content that hit the bar you expect. Use these to:
- Show your team what quality looks like
- Onboard new hires
- Maintain consistency

### Page 2: Content Funnel & Stack

**1. Rented Audience (Social Platforms)**
Where you attract attention - you don't own these platforms.

**Options:**
- Twitter
- LinkedIn
- YouTube
- YouTube Shorts
- TikTok
- Instagram Posts
- Instagram Stories
- Facebook Pages

**My Recommendation:** Pick 2 platforms and nail them. Don't spread yourself thin.

**My Example:**
- Twitter (primary)
- LinkedIn (secondary)
- YouTube Shorts (expanding to)

**2. Owned Audience (Email & SMS)**
Convert rented audience to owned audience.

**My Example:**
- Email: Newsletter (Beehive)
- SMS: Phone numbers

**3. Monetized Audience**
People who pay you.

**My Example:**
- Founder OS Program
- Founder OS Newsletter (premium)
- Henzo (SaaS tool)

**4. Tech Stack**
Tools you use to execute your content strategy.

**My Example:**
- **HypeFury** - Schedule Twitter content
- **Publer** - Schedule LinkedIn content
- **Beehive** - Newsletter platform
- **Kajabi** - Course platform
- **Zoom** - Workshops
- **Testimonial.to** - Gather testimonials
- **Twemex** - Find top tweets
- **Notion** - Save content templates
- **Google Sheets** - Organize content
- **Grammarly** - Check grammar

**5. Creator Inspiration**
People you learn from and draw inspiration from.

**My Example:**
- **Harry Dry** - Copywriting
- **Austin Belkak** - LinkedIn content
- **Dickie Bush** - Twitter content
- **Alex Lieberman** - Strategy and newsletter (Morning Brew founder, 3M+ subscribers)
- **Cody Sanchez** - YouTube (grew 1.9M followers in 12 months)
- **Sam Ovens** - Community ($35M/year course business)

## The Four Pillars of Amazing Copywriting

Copywriting is a salesperson that never sleeps. While you sleep, your content is working for you - generating leads, building trust, and driving sales.

**The 4 Pillars:**

### 1. EDUCATE
Builds trust with your niche.

**Templates:**
- "How to [achieve result] in [timeframe]"
- "The [number] step framework for [outcome]"
- "What I learned from [experience]"

### 2. ENTERTAIN
Generates awareness, makes people stop scrolling.

**Templates:**
- Stories that hook emotionally
- Unexpected observations
- Contrarian takes
- Behind-the-scenes content

### 3. ENGAGE
Drives emotional connection, builds community.

**Templates:**
- Ask questions
- Create polls
- Respond to everyone early on
- Make people feel seen

### 4. EMOTION
Makes your dream customer feel something.

**Emotions to optimize for:**
- **LOL** - Damn, that's so funny
- **WTF** - Damn, that pisses me off
- **AW** - That's so cute
- **NSFW** - Damn, that's crazy
- **OHH** - Now I get it (learning moment)
- **YAY** - Great news, achievement, success
- **FINALLY** - Finally someone's saying it

**The more emotions you can pack into content, the more virality, engagement, and shareability you create.**

## The 80% Rule: Hooks Matter Most

**80% of your content's success is the HOOK (first sentence).**

The goal:
1. Read the first sentence
2. Then read the second sentence
3. Then read the third sentence

Every single sentence matters. Carefully manufacture your hooks to be scroll-stopping.

## Copywriting Resources

**Books:**
- Adweek Copywriting Handbook

**Websites:**
- copywritingexamples.com (bookmark this!)

**Tools:**
- Twemex (Chrome extension - see top tweets from any creator)
- HypeFury templates (fill-in-the-blank content)

## Content Ideation: 4 Sources

### 1. Data
Use analytics to see what's working.

**Tools:**
- **Shield App** (LinkedIn analytics) - See top posts, word clouds
- **Ilo** (Twitter analytics) - Track impressions, engagements, growth
- Native platform analytics

**Strategy:** Look at what performed well, create more of that.

### 2. Tech/Platforms
Save content you love on each platform.

**Where to save:**
- **Twitter:** Bookmarks
- **LinkedIn:** Saves
- **Instagram:** Collections
- **YouTube:** Saved videos

**Strategy:** When creating content, reference your saved inspiration. Never have writer's block again.

### 3. Creators
Learn from the best in your space.

**How:**
- Use Twemex to see their top-performing content
- Study their hooks, topics, and formats
- Go to their profiles, sort by "most popular"
- Remix their patterns for your niche

**Strategy:** Stand on the shoulders of giants. Learn patterns, don't copy.

### 4. Templates
Use fill-in-the-blank templates to create fast.

**HypeFury Templates Examples:**
- "[Thing] is a drug" → "Momentum is a drug"
- "Do less [blank], do more [blank]"
- "You don't need [blank], you need [blank]"

**Strategy:** Use templates to create 40+ posts in 10 minutes.

## The Content Queue System

**Goal:** Build a 30-60 day content queue so you're never scrambling.

**My System:**
1. Block 2 hours for content creation
2. Use templates, saved inspiration, and data
3. Create 30-60 pieces of content
4. Schedule them in advance
5. Never think about "what to post today"

**Tools:**
- HypeFury (Twitter scheduling)
- Publer (LinkedIn scheduling)
- Beehive (Newsletter)

**Cadence:**
- Twitter: 2x per day (8am, 2pm)
- LinkedIn: 2x per day (8am, 2pm)
- Newsletter: 1x per week (Saturday AM)

## Building in Public

**What to share:**
- Your successes
- Your failures
- What's working
- What's not working
- Tools you're using
- Systems you're loving
- What you're learning

**Benefits:**
- Find mentors online
- Meet similar people
- Refine your content engine
- Cultivate vibrant community
- 1000x your surface area for luck
- Meet customers where they are
- Market yourself by documenting

## The Revenue Matrix: Growing Monetized Audience

### LinkedIn Revenue Tactics
1. Drive emails via featured section
2. Drive emails via first comment link
3. Post direct links to newsletter
4. Create high purchase intent content
5. Share testimonials constantly

### Twitter Revenue Tactics
1. Drive emails via profile link (use Linktree or similar)
2. Post newsletter links directly
3. Create top-of-funnel awareness content
4. Create high purchase intent content
5. Share testimonials and case studies

### Instagram Revenue Tactics
1. Drive emails via link in stories
2. Drive emails via link in bio
3. Tease lead magnet to newsletter
4. Share newsletter snippets
5. Post testimonials
6. High purchase intent content

**The Formula:**
Social Media → Newsletter → Customers

- Grow social following
- Convert to email subscribers
- 2-5% of email list converts to customers
- Bigger email list = More customers

**Example:** 14,000 new newsletter subscribers/month × 2% conversion = 280 new customers/month

## Consistency is Everything

**My Belief:** Compounding is the 9th wonder of the world.

**The Reality:**
- Week 1: Maybe 20 subscribers
- Week 2: Maybe 30 subscribers
- Month 6: Momentum building
- Year 2: Exponential growth

**The Secret:**
- Don't worry about today or tomorrow
- Play the 5-year, 10-year game
- Stack excellent days
- Start your compounding TODAY

**Action Step:**
Publish at least 3 pieces of content in the next week. Just start.

## My Mental Clarity System

### Morning Routine (6am)
1. Wake up naturally after 8 hours sleep
2. Drink water, take vitamins
3. Go for a walk (sunlight in eyes - circadian rhythm)
4. Get coffee
5. Sit down and complete 5 power tasks
6. Peak motivation = peak productivity

### Midday
1. Lift heavy weights
2. Stretch
3. 10-minute meditation
4. Shower
5. Complete more tasks

### Afternoon
1. Fast until 2pm
2. Eat smoothie or salad (food is medicine)
3. Meetings from 2-7pm

### Evening
1. Prepare or order dinner
2. Read
3. Curate inspiration for tomorrow
4. Organize next day's 9 tasks
5. Stretch
6. Abundance meditation
7. Sleep

### Weekly
- **Saturday:** Unplug for most of the day (maybe 4 hours creative work)
- **Sunday:** Reflect on progress, review personal board meeting, set next week goals

### Every 6 Weeks
- **Soul Trip:** Bucket list item, adventure, inspiration

**Examples:**
- Surfing in Mexico coast
- Hiking in mountains
- Foraging mushrooms in forest
- Any adventure that refuels creativity

**Why:** Infuses your brain with clarity, energy, inspiration. Cool life = Cool content = Cool community.

## The 60-Day Content Challenge

**Concept:** 60 days of proven templates that have generated 200+ million views.

**How It Works:**
1. Use daily templates (fill in the blank)
2. Publish at least 1 piece of original content per day
3. Adapt templates to your niche and voice
4. Track what works, double down

**Tools:**
- HypeFury (Twitter)
- Taplio (LinkedIn)
- Build 60-day content queue

**Result:** In 10 days, friends will reach out saying "Damn, love your content!"

## Key Metrics to Track

### Audience Growth
- Email subscribers (most important)
- Social media followers (engaged, not just vanity)
- Community members
- Content engagement rate

### Content Performance
- Impressions
- Engagement rate
- Click-through rate
- Earned media value

**My Results:**
- **LinkedIn:** 27M views YTD = $218,000 free marketing
- **Twitter:** 40k followers/month, 601k daily impressions, 64k daily profile clicks

### Conversion Metrics
- Social → Email conversion rate
- Email → Customer conversion rate
- LTV:CAC ratio
- Referral rate

## Common Mistakes to Avoid

❌ **Spreading too thin** - Pick 2 platforms, nail them
❌ **Being inconsistent** - Consistency beats perfection
❌ **Not curating inspiration** - You'll have writer's block
❌ **Perfectionism** - Done > Perfect
❌ **Ignoring data** - Let performance guide you
❌ **No content queue** - You'll burn out on the treadmill
❌ **Not building owned audience** - Social platforms can disappear
❌ **Forgetting to monetize** - Audience without revenue isn't sustainable

## Resources & Tools Summary

**Content Creation:**
- HypeFury (Twitter scheduling & templates)
- Publer (LinkedIn scheduling)
- Notion (Content templates)
- Google Sheets (Content organization)
- Grammarly (Grammar checking)

**Curating Inspiration:**
- Twemex (Top tweets)
- Twitter Bookmarks
- LinkedIn Saves
- Instagram Collections

**Newsletter:**
- Beehive (recommended - built by Morning Brew founders)

**Analytics:**
- Shield App (LinkedIn)
- Ilo (Twitter)
- Native platform analytics

**Learning:**
- copywritingexamples.com
- Adweek Copywriting Handbook
- Follow top creators in your niche

## Taking Action

**This Week:**
1. Fill out your 2-page content strategy
2. Pick your 2 platforms
3. Set up your tech stack
4. Start curating inspiration (save 10 pieces of content you love)
5. Publish 3 pieces of content

**This Month:**
1. Build a 7-day content queue
2. Establish your content franchise (weekly newsletter or regular post series)
3. Create your best in class examples
4. Start tracking your metrics

**This Quarter:**
1. Build a 30-day content queue
2. Grow your newsletter to first 1,000 subscribers
3. Refine based on data
4. Start monetizing

Remember: **Excellence is a habit. Consistency is key. Start your compounding today.**

Let's set your community on fire. Let's win together. Much love!
