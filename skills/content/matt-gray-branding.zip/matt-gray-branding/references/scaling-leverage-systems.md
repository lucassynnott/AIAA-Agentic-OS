# Scaling Your Business: The Leverage Triangle

## The Core Philosophy

**You are only as strong as your systems.**

Over 12 years, I've refined this model: **The Leverage Triangle**
- **People**
- **Product**
- **Process**

These three create leverage. As entrepreneurs, we must always look for ways to build leverage.

## PEOPLE: Hiring Legends

### The Hiring System

It all comes down to people. People create the product. People help you achieve your vision.

**The power of an amazing hire cannot be understated.** A great hire (like my Chief Revenue Officer at Herb) can completely change your business trajectory.

### Step 1: Create a Role Scorecard

**BEFORE you hire anyone**, create a scorecard. This is an internal document that filters who's right and wrong.

**Scorecard Template:**

1. **Role:** (e.g., Account Executive)

2. **Mission:** What is this role trying to achieve?
   - *Example:* "Help Herb achieve $400k MRR by selling Cannabis Marketing as a Service to cannabis brands"

3. **Outcomes:** Specific, measurable results they need to drive
   - *Example for Account Executive:*
     - Reach out to X brands per day/month
     - Set up 30 meetings per month
     - Win rate of X% (close Y opportunities per month)

4. **Competencies:** Skills/qualities they must have
   - *Example for Account Executive:*
     - Energy, tenacity, chip on shoulder
     - Impeccable written and oral communication
     - Persuasive
     - **Mission and culture fit** (ALWAYS include this)

### Competencies Guide

I've categorized competencies by how easy they are to change:

**Relatively Easy to Change:**
- Self-awareness
- Organization
- Time management
- Attention to detail

**Harder but Doable:**
- Communication skills
- Creativity
- Problem-solving
- Leadership

**Very Difficult to Change:**
- Analysis skills
- Strategic thinking
- Tenacity
- Cultural fit
- Energy level

**Hiring Tip:** If someone lacks a "very difficult to change" competency you need, don't hire them. If they lack an "easy to change" one, you can train them.

### Step 2: Create a Compelling Job Description

**Jedi Tip:** Steal from billion-dollar companies' careers pages.

- Hiring a content person? Check Shopify or Facebook
- Hiring a software engineer? Check Palantir or TikTok
- Hiring a writer? Check what billion-dollar companies do

**Job Description Template:**

1. **Company Mission** (from your Vision Board)
2. **Problem you solve**
3. **Your solution**
4. **Traction so far**
5. **Role overview**
6. **What they'll complete in:**
   - 30 days
   - 60 days
   - 90 days
7. **Type of people you want**
8. **Team information**
9. **Who leads the team**
10. **How to apply**

### Step 3: Interview Questions Bank

**My Go-To Questions (Bolded ones I use every time):**

- **What motivates you?** (Looking for energy/tenacity)
- **What frustrates you?** (Red flags: don't take direction?)
- **Are you a storyteller?** (Narratives drive brands)
- **How do you motivate people?**
- **How did you hear about the role?** (Find which channel works)
- **Would you ever want to be a CEO?** (Do they take responsibility?)
- **What is your time commitment for this role?** (Looking for dedication)
- **What separates a great from good [insert role]?** (Understanding of excellence)
- **What book would you recommend to me and why?** (Are they students?)
- **What are you most embarrassed or regretful about?** (Vulnerability, life experience)
- **What important truth do very few people agree with you on?** (Peter Thiel question - problem-solving, thinking on feet)

### Step 4: Market the Position

Post to:
- Your careers page
- Internal job board
- Share with your network
- Use outreach templates (more below)

**Remember:** The scorecard is your filter. If someone shows up late when you need tenacity - get out of here. If you need attention to detail but their writing sample has mistakes - get out of here.

## PRODUCT: Making Something People Want

### The Core Principle (from Y Combinator)

**Make something people want.**

This principle has produced companies like Airbnb, Reddit, Dropbox, and Instacart.

### The Sean Ellis Test

Survey your customers and ask:

**"How would you feel if you could no longer use [your product]?"**
- Very disappointed
- Somewhat disappointed
- Not disappointed

**Product-Market Fit = 60%+ say "Very disappointed"**

If only 20% would be very disappointed, you need to refine. Talk to customers. Get outside the building. Figure out what they really need.

### Survey Questions to Ask

1. How would you feel if you could no longer use our product?
2. What type of people would most benefit from our product?
3. What is the main benefit you receive from us?
4. How can we improve?
5. How likely are you to recommend us to a friend or colleague? (NPS score)

**Use the answers to:**
- Understand product-market fit
- Find better marketing copy (use their words!)
- Identify what channels to acquire customers through
- Get testimonials
- Build referral loops

**The Goal:** Get each customer to refer 3 people. That's your viral loop.

### Growing Your Monetized Audience

**The Formula:**
Rented Audience (Social) → Owned Audience (Email) → Monetized Audience (Customers)

**Revenue Matrix Checklist:**

**On LinkedIn:**
- Drive emails via featured section
- Drive emails via first comment link
- Post direct links to email list
- Create high purchase intent content
- Share testimonials

**On Twitter:**
- Drive emails via profile link
- Post newsletter links
- Create top-of-funnel content
- Create high purchase intent content
- Share testimonials

**On Instagram:**
- Drive emails via link in stories
- Drive emails via link in bio
- Tease lead magnet for newsletter
- Share newsletter snippets
- Share testimonials

**The Math:**
Bigger newsletter = More customers
- If 2-5% of email subscribers become customers
- 14,000 new subscribers/month = 280-700 new customers/month

## PROCESS: Automate, Eliminate, Delegate

### The Core Principle

**Automate, Eliminate, Delegate = AED**

This is how you 1000x your business.

**Automate:**
- Systemize recurring tasks
- Document them
- Use technology to handle them

**Eliminate:**
- Audit everything you do
- If it doesn't accelerate your vision, CUT IT
- Be ruthless with your time
- Time is your most valuable asset

**Delegate:**
- If someone can do it 80% as well as you, delegate it
- Create system/template first
- Give them best-in-class examples
- Let them handle it

**Examples of what to delegate:**
- Instagram captions
- Scheduling content
- Customer service responses
- Data entry
- Research

**What NOT to delegate (initially):**
- Strategy
- Vision
- Core product decisions
- Culture building
- Key partnerships

### The Company Wiki

**Purpose:** Knowledge base for everything in your company.

**My Herb Wiki took 9 years to build.** Thousands of hours. This is your onboarding machine.

**Structure:**

```
Company Wiki/
├── HR/
│   ├── Hiring processes
│   ├── Onboarding flows
│   └── Company policies
├── Tech/
│   ├── Tools we use
│   ├── Technical processes
│   └── Access instructions
├── Design/
│   ├── Brand guidelines
│   ├── Design systems
│   └── Asset library
├── Marketing/
│   ├── Content strategy (your 2-pager!)
│   ├── Social media processes
│   └── Campaign templates
├── Sales/
│   ├── Sales scripts
│   ├── Objection handling
│   └── CRM processes
├── Operations/
│   ├── Standard operating procedures
│   ├── Tools and systems
│   └── Workflows
├── Brand/
│   ├── Mission, vision, values
│   ├── Brand voice
│   └── Messaging
├── Social Media/
│   ├── Platform strategies
│   ├── Posting schedules
│   └── Engagement protocols
├── Partnerships/
│   ├── Partnership agreements
│   ├── Outreach templates
│   └── Relationship management
└── Finance/
    ├── Budgeting processes
    ├── Expense policies
    └── Financial reporting
```

**How to Build Your Wiki:**

1. **Start in Notion** (or Google Drive)
2. **Don't try to complete overnight** - This takes years
3. **Mindset shift:** Every week, create a couple systems
4. **When you do something repeatedly:** Document it
5. **Add to wiki gradually**
6. **New hires read EVERYTHING** - Line by line, page by page

**The Result:**
New hires take your brain and put it in their brain. They learn your systems, your processes, and how you do business.

**Game changer.**

### My Creation Process

**Evening Before:**
1. Curate inspiration
2. Make list of exactly what I need to get done (9 tasks)
3. Organize everything

**The Super Bowl is won in the preseason.** Prepare the night before.

**Morning (6am):**
1. Wake up with incredible energy (8 hours sleep)
2. Know exactly what I need to get done
3. Go line by line through checklist
4. Hammer it out

**Break:**
1. Walk for 45-60 minutes
2. Listen to music
3. Relax, grab coffee or sparkling water
4. Get sun in eyes
5. Take in nature

**Return:**
1. Complete more tasks OR
2. Edit what I just created

**The key:** Preparation + Focus + Breaks = Maximum productivity

### My Daily Operating System

**Morning (5-6am):**
- Wake naturally after 8 hours sleep
- Drink water, take vitamins
- Go for walk
- Complete 5 power tasks (peak motivation = peak productivity)

**Mid-Morning:**
- Lift heavy weights
- Stretch
- 10-minute meditation
- Shower
- Complete more tasks

**Afternoon:**
- Fast until 2pm
- Eat smoothie or salad (food is medicine)
- Meetings from 2-7pm

**Evening:**
- Prepare/order dinner
- Read
- Curate inspiration
- Organize next day's 9 tasks
- Stretch
- Abundance meditation
- Sleep

**Weekly:**
- Saturday: Unplug (maybe 4 hours creative work)
- Sunday: Reflect on progress, review personal board meeting, set next week goals

**Monthly:**
- Last Sunday: Create next month's goals in personal board meeting
- Use Henzo software tool for tracking

**Quarterly (Dec 30, Mar 30, Jun 30, Sep 30):**
- Reflect on quarter
- Create new quarterly goals

**Annually (Dec 23 - Jan 3):**
- 4 days: Complete unplug
- 3 days: Journal and reflect
  - What went well, what didn't
  - What gave energy, what sucked energy
  - Use to create next year's goals
  - Cut what drains, double down on what energizes

**Every 6 Weeks:**
- Soul trip (bucket list item)
- Examples: Surfing Mexico, hiking mountains, foraging mushrooms
- Build your life resume

**Why soul trips matter:**
- Infuse brain with clarity, energy, inspiration
- Cool life = Cool content = Cool community

## Building Your Personal Board of Advisors

**Belief:** 80% of my success has been standing on the shoulders of giants.

### Who Should Be on Your Board?

Assemble an Avengers team around you in areas like:
- Marketing
- Growth
- Sales
- Strategy
- Finance

**My Board Examples:**
- **Toby Lütke** - Founder/CEO Shopify, richest man in Canada (invested in Herb)
- **Rich Antoniello** - Sold Complex to BuzzFeed for ~$200M
- **Cody Sanchez** - Grew 1.9M followers in 12 months on YouTube
- **Jesse Itzler** - Sold Zico to Coca-Cola, NetJets to Berkshire Hathaway
- **Alex Lieberman** - Morning Brew founder (grew to 3M+ subscribers)
- **Sam Ovens** - $35M/year course business

**Your 5 closest people = 80% of your success.**

### How to Build Your Board

**Step 1: Make Your List**

Look at:
- Who you follow on Twitter
- Who you like on LinkedIn
- Newsletters you read
- Books you love
- Founders you admire

**Step 2: Find Their Contact Info**
- Email address
- Instagram handle
- Twitter handle
- LinkedIn

**Step 3: Provide Value First**

**The Formula: Give, Give, then Get**

**Examples of providing value:**
- Send loom video with 2-minute hack for their business
- Scrub their product, provide suggestions
- Test their website, note errors or improvements
- Share a system/Google Doc that helps them
- Introduce them to someone valuable

**Reciprocity is one of the most powerful psychological biases.** When you provide value, they want to return the favor.

### Outreach Templates

**Template 1: Direct Ask**

"Hey [Name], this is Matt from Herb. Our mission is to change the way the world views cannabis. Our vision is to get anyone in the world Cannabis in under 15 minutes and free every person incarcerated for cannabis globally.

I wanted to chat with you about [specific thing - how you took your business from $10M to $50M/year]. I'm currently at the $6M mark with Herb and want to take it to $20M next year. I'd love to get your two cents on this.

Do you have 10 minutes to chat on Thursday at 4pm PT?"

**Template 2: Value First**

"Hey [Name], I noticed you have [observation]. I made you a quick 2-minute loom video on [how to solve their problem with hacks I've learned]: [link]

Hope this helps!"

*They respond thanking you*

"Yeah man, doing really well. Working on [your business] right now. Would love to connect with you on [their expertise]. Got 2 minutes to chat maybe tomorrow?"

### Tools to Speed Up Outreach

**TextExpander (Mac):**
- Save snippets
- Type semicolon + shortcut
- Instantly outputs your template
- Example: `;int` → Full intro message

**Saves 45 minutes per day.**

**iPhone Text Replacement:**
- Settings → Keyboards → Text Replacement
- Save same snippets for mobile
- Use on Instagram DMs, Twitter DMs, LinkedIn messages

**Yesware (Gmail):**
- Create email templates
- Insert with one click
- Track opens and clicks
- Save different folders of templates

**My outreach volume: 50 outreaches per day.**

**Belief:** Your net worth is your network. The bigger your network, the more you'll make. You're increasing your surface area of luck.

### Real Story: The Power of Network

**Bitmaker Crisis:**
- Front page of Globe and Mail (biggest paper in Canada)
- Ministry showed up: "We're shutting you down in 30 days"
- Could be fined $500k and jailed for 1 year
- Completely outrageous situation

**My Response:**
- Sent 1,200 emails that evening to my network
- Reached out to Paul Graham (Y Combinator), Chamath (Facebook), Vinod Khosla (Sun Microsystems founder)
- Mobilized students, hiring partners like Shopify
- Within 24 hours: Trending on Twitter in Canada
- Within 48 hours: On call with Minister
- Result: "This was a huge mistake. We're giving you an exemption. Super sorry."

**Got the only exemption in Canada = Competitive advantage → 8-figure exit**

**How did this happen?**
- Network
- Outreach
- Templates
- Daily discipline
- Daily consistency
- Using tools and systems
- Putting my energy to good use

## The Importance of Coaching

**My Belief:** Entrepreneurs are like athletes.

- Michael Jordan had a coach
- Serena Williams had a coach
- Kobe had a coach

**You need a coach.**

**Why:**
- So many blind spots building a business
- Difficult moments that leave you down and out
- Sometimes you just get punched in the face despite best effort
- You need help

**Types of Coaching:**

**Informal:**
- Tap someone on shoulder monthly
- Informal relationship
- Free

**Formal:**
- Pay someone bi-weekly to help
- More accountability
- Deeper support

**Where to find:**
- Your personal board of advisors
- Founder OS community
- Me (DM if you need help)

**Reality:** Building a business is hard. Surround yourself with mentors, legends on your team, and coaches.

## Founder OS Community Values

**1. Every day is day one**
- Bring tenacity
- Give life your best
- Get the best out of life

**2. Automate, Eliminate, Delegate**
- Use the hiring systems
- Create content systems
- Get rid of stuff off your plate

**3. Make magic possible**
- Use your innate talent
- We're the best of the best
- Bring tenacity, energy, creativity daily

**4. Invent and Wander**
- Take time for yourself
- Mental health is important
- Creativity fueled by nature
- Take soul trips every 6 weeks
- Build your life resume
- Do cool shit

**5. Optimize for Flow**
- Wake up early
- Go for a walk
- Get deep work time in
- Mornings are sacred
- Phone on do not disturb
- Block calendar
- Eliminate distractions
- Get after it relentlessly

**6. Hire Legends**
- You're a legend
- Hire people you admire
- Let's help one another find great people
- Share opportunities in community
- We're stronger together

## Key Takeaways

### On People
- Use the scorecard system BEFORE hiring
- Steal job descriptions from billion-dollar companies
- Use proven interview questions
- Fit with your values is non-negotiable
- Bad hires cost ~$70k+ and cultural damage

### On Product
- Aim for 60%+ "very disappointed" on Sean Ellis test
- Listen to your customers
- Use their words in your marketing
- Build referral loops (1 customer → 3 referrals)
- Continually refine based on feedback

### On Process
- Automate, Eliminate, Delegate everything
- Build your company wiki gradually
- Document recurring tasks
- Onboard new hires with your wiki
- Use tools to speed up outreach

### On Leverage
- People create products
- Products serve customers
- Processes scale everything
- You're only as strong as your systems
- Build leverage to work ON the business, not IN it

### On Support Systems
- Find a coach (informal or formal)
- Build your personal board of advisors
- Provide value first (give, give, get)
- Your network = Your net worth
- Community is your unfair advantage

**Remember:**
- Consistency is key
- Excellence is a habit
- Every day is day one
- You're only as strong as your systems
- Let's win together

Much love. Let's get it!
