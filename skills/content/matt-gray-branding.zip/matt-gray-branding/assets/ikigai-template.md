# Your Ikigai Exercise Template

## Instructions

Fill out each section with 2-5 bullet points. Be honest and authentic. Look for patterns and common themes across sections - these often point to your Ikigai.

---

## What You LOVE
*What activities make you lose track of time? What would you do even without payment?*

1.
2.
3.
4.
5.

---

## What the World NEEDS
*What problems do people face? What gaps exist in the market? What would make lives better?*

1.
2.
3.
4.
5.

---

## What You Can Be PAID FOR
*What skills or services have you been paid for? What would people pay you to do?*

1.
2.
3.
4.
5.

---

## What You Are GOOD AT
*What do people constantly ask for your help with? What comes naturally? What's your superpower?*

1.
2.
3.
4.
5.

---

## Intersections

### PASSION (What you LOVE + What you're GOOD AT)
*What activities bring you joy AND you excel at?*



### MISSION (What you LOVE + What the world NEEDS)
*What causes or purposes deeply resonate with you?*



### VOCATION (What the world NEEDS + What you can be PAID FOR)
*What profitable opportunities exist in the market?*



### PROFESSION (What you're GOOD AT + What you can be PAID FOR)
*What are your monetizable skills?*



---

## YOUR IKIGAI
*At the center of all four circles - this is your reason for being*

**Common themes across all four areas:**




**Your Ikigai (your calling):**




**Is this a "full body yes"?**
- Mind (logical):
- Heart (emotional):
- Gut (instinctual):

---

## Your Profitable Niche

**Your Skills:**


**Your Interests:**


**Monetization Strategy:** (Pick 1-3 from: SaaS, Community, Coaching, Course, Services, Digital Products, etc.)
1.
2.
3.

**Your Profitable Niche:**
*Describe in one sentence what you help people do and how you make money*



---

## Next Steps

1. Review this weekly - Ikigai evolves
2. Use as a filter for all opportunities
3. Say NO to anything not aligned
4. Double down on what energizes you
5. Build your personal brand around this

Remember: **If it's not a hell yes, it's a no.**
